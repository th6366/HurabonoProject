// 리눅스 커널에서 연결리스트를 구현하는 방식
#include <stdio.h>
#include <stdlib.h>

// '단일 연결리스트' 오로지 정방향으로 처리가 가능합니다.
// '역방향에 대한 처리가 필요하다.'
//  => 이중 연결 리스트

typedef struct _node {
	int data;
	struct _node* prev;
	struct _node* next;
} NODE;

void insert_back(NODE* head, NODE* temp)
{
	temp->next = head->next;
	head->next = temp;

	temp->prev = head;
	temp->next->prev = temp;
}

void insert_front(NODE* head, NODE* temp)
{
	temp->next = head;
	head->prev->next = temp;

	temp->prev = head->prev;
	head->prev = temp;
}

void display(NODE* head)
{
	NODE* temp;
	
	system("clear");
	printf("[head]");
	for (temp = head->next ; temp != head ; temp = temp->next)
	{
		printf("-> [%d]", temp->data);
	}
	putchar('\n');
	getchar();
}

int main()
{
	int i;

	// 메모리 풀을 연결리스트 묶어서 관리할 수 있다.
	NODE head = {0, &head, &head};
	NODE nodes[7];

	display(&head);
	for (i = 0 ; i < 7 ; ++i)
	{
		nodes[i].data = i + 1;
		insert_front(&head, nodes + i);
		display(&head);
	}
}